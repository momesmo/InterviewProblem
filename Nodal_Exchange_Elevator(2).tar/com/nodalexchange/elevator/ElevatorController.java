package com.nodalexchange.elevator;

public interface ElevatorController {
	public void cycleElapsed(Building building);
}
