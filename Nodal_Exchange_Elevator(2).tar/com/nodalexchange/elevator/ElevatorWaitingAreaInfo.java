package com.nodalexchange.elevator;

public interface ElevatorWaitingAreaInfo {
	public boolean isUpButtonPushed();
	public boolean isDownButtonPushed();
}